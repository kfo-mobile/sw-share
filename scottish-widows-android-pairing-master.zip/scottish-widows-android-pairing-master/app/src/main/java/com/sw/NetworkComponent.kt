package com.sw

import android.util.Log
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

class NetworkComponent {

    fun makeRegistrationRequest(registrationModel: RegistrationModel) {
        val json = adapter.toJson(registrationModel)
        Log.d("RegistrationRequest", " \n\n Request made with body: \n\n $json \n\n ")
    }

    private val adapter = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()
        .adapter(RegistrationModel::class.java)
        .indent("    ")
}

