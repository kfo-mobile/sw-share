package com.sw

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import com.sw.databinding.ActivityRegistrationBinding

class RegistrationActivity : AppCompatActivity() {

    private lateinit var firstNameEditText: EditText
    private lateinit var lastNameEditText: EditText
    private lateinit var ageEditText: EditText
    private lateinit var pensionTypeRadioGroup: RadioGroup
    private lateinit var passwordEditText: EditText
    private lateinit var doneButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val binding = ActivityRegistrationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firstNameEditText = binding.firstNameEditText
        lastNameEditText = binding.lastNameEditText
        ageEditText = binding.ageEditText
        pensionTypeRadioGroup = binding.pensionTypeRadioGroup
        passwordEditText = binding.passwordEditText
        doneButton = binding.doneButton
    }
}
