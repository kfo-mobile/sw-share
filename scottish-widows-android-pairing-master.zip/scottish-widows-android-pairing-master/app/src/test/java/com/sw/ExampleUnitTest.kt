package com.sw

import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun test() {
        val result = true
        assertTrue(result)
    }

}